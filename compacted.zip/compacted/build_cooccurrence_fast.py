from multiprocessing import context
from multiprocessing.process import current_process
from os import write
import re
from typing import ContextManager
from whoosh.fields import NUMERIC, Schema, TEXT, ID
from whoosh import index

import numpy as np

import whoosh
import math
from whoosh.qparser import QueryParser

import json

import csv
 
import os.path

from whoosh.qparser.syntax import WordNode

concept_words = []
total_concept = 10000

# load all concepts words and store into concept_words list
with open("Keywords-Springer.csv") as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=",")
    counter = 0
    for row in csv_reader:
        if counter == total_concept:
            break
        concept_words.append(row[0])
        counter += 1
print("done with keyword")

schema = Schema(content=TEXT(stored = True), index=NUMERIC(stored=True))
 
ix = index.create_in("indexdir", schema)

total_document = 10000

document_index = 0

word_index = 0

# document frequency table, each entry (i, j) stores whether concept i appears in document j
df_table = np.array([[0]*total_document]*len(concept_words))

writer = ix.writer()

counter = 0

# loads all documents into whoosh writer
with open('arxiv-metadata.json', "r") as files:
    for jsonObject in files:
        if counter == total_document:
            break
        abstract = (json.loads(jsonObject)["abstract"]).replace("\n", " ")
        writer.add_document(content=abstract, index=document_index)
        document_index += 1
        counter += 1
writer.commit()

print("done commit files")

# fill out the df table by searching concept words one by one to see whether they are in the documents
with ix.searcher() as searcher:
    for concept in concept_words:
        arr = concept.split(" ")
        query_words = []
        for word in arr:
            query_words.append(word)
        query = whoosh.query.Phrase("content", query_words)
        # query = QueryParser("content", ix.schema).parse(f"{concept}~1")
        results = searcher.search(query, terms=True)
        for r in results:
            df_table[word_index][r["index"]] += 1
        word_index += 1

print("done building df_table")

# get the co-occurence tables
ct = np.dot(df_table, np.transpose(df_table))

print("done matrix multiplication")

top_words = np.array([[0, 0, 0, 0, 0] for i in range(total_concept)])

next_goal = 1000
# line 100 - 184 are used to generate the top 3 relavant concepts for each concept, and the snippet of the document they are both in
# and store them inside the file "store_snippet" and "top_3_concepts"
with ix.searcher() as searcher, open("store_snippet", "w") as snippet_output, open("top_3_concepts", "w") as concept_output:
    # list all concepts in the first line
    for concept in concept_words:
        concept_output.write(concept)
        concept_output.write(",")
    concept_output.write("\n")
    for i in range(total_concept):
        if i == next_goal:
            print(next_goal)
            next_goal += 1000
        frequency_to_index = {}
        # set all (i, i) to 0 and build frequency_to_index
        for j in range(total_concept):
            if i == j:
                ct[i][j] = 0
            if ct[i][j] in frequency_to_index:
                frequency_to_index[ct[i][j]].append(j)
            else:
                frequency_to_index[ct[i][j]] = [j]
        # get the first 5 most related concept terms in the form of (frequency, index)
        frequency_to_index = sorted(frequency_to_index.items(), key=lambda x:x[0], reverse=True)[:6]
        count_number = 0
        list_index = 0
        curr_list = frequency_to_index[0][1]
        tmp_list = []
        while count_number < 5:
            if len(curr_list) == 0:
                list_index += 1
                curr_list = frequency_to_index[list_index][1]
            tmp_list.append((frequency_to_index[list_index][0], curr_list.pop()))
            count_number += 1
        frequency_to_index = tmp_list

        counter = 0
        concept_index_to_snippets = {}


        # iterate through the top 5 concepts and re-score in consideration of word distance, and find the top 3 in the end.
        for curr_concept in frequency_to_index:
            if curr_concept[0] == 0:
                break
            first_concept = concept_words[i]
            second_concept = concept_words[curr_concept[1]]
            arr = first_concept.split(" ")
            # search in documents by the two concepts
            first_query = []
            for word in arr:
                first_query.append(word)
            first_query = whoosh.query.Phrase("content", first_query)

            arr = second_concept.split(" ")
            second_query = []
            for word in arr:
                second_query.append(word)
            second_query = whoosh.query.Phrase("content", second_query)
            query = QueryParser("content", ix.schema).parse(f"{first_query} AND {second_query}")
            results = searcher.search(query, terms=True)
            total_distance = 0
            snippet_list = []
            n_relavant_doc = 0
            # iterate through all document it finds
            for c in range(3):
                # if the number of document in the search result is smaller than 3, we insert "null"
                if c >= len(results):
                    snippet_list.append("null")
                    continue
                n_relavant_doc += 1
                curr_doc = results[c]["content"]
                first_index = curr_doc.find(first_concept)
                second_index = curr_doc.find(second_concept)
                # calculate the distance and generate snippets
                distance = abs(first_index - second_index)
                large_index = max(first_index, second_index)
                small_index = min(first_index, second_index)
                if distance < 100:
                    snippet_list.append(curr_doc[max(0,small_index-50):min(large_index+50,len(curr_doc))])
                else:
                    str_to_add = "..." + curr_doc[max(0,small_index-50):min(small_index+50,len(curr_doc))] + "...[eliminate "+ str(large_index - small_index - 100) + " words]..." + curr_doc[max(0,large_index-50):min(large_index+50,len(curr_doc))] + "..."
                    snippet_list.append(str_to_add)
                total_distance += distance
            # build concept_index_to_snippets in the form [concept index: snippet_list]
            concept_index_to_snippets[curr_concept[1]] = snippet_list
            # update each concept scores by their word distance
            frequency_to_index[counter] = (curr_concept[0] + math.log(1000 / (total_distance / (n_relavant_doc + 1) + 1)), curr_concept[1])
            counter += 1
        frequency_to_index = sorted(frequency_to_index, key=lambda x:x[0], reverse=True)[:3]
        # write output to the files
        counter = 0
        for curr_concept in frequency_to_index:
            counter += 1
            # if the number of relavant document is less than 3, we write 3 nulls in the 'store snippets' and -1 in the 'top 3 concept' to indicate concept not found
            if curr_concept[0] == 0:
                for c in range(3):
                    snippet_output.write("null\n")
                concept_output.write("-1")
                concept_output.write(",")
            # write all snippets and relavant concepts into files
            else:
                for snippet in concept_index_to_snippets[curr_concept[1]]:
                    snippet_output.write(snippet)
                    snippet_output.write("\n")
                concept_output.write(str(curr_concept[1]))
                concept_output.write(",")
        for curr_concept in frequency_to_index:
            if curr_concept[0] == 0:
                concept_output.write("-1")
            else:
                concept_output.write(str(curr_concept[0]))
            concept_output.write(",")
        concept_output.write("\n")

print("find top 3 concepts and store snippets done")

with open("cooccurance_table_fast", "w") as output:
    for concept in concept_words:
        output.write(concept)
        output.write(",")
    output.write("\n")
    for row in ct:
        for item in row:
            output.write(str(item))
            output.write(",")
        output.write("\n")




