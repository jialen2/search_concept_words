from multiprocessing import context
from multiprocessing.process import current_process
from os import write
from typing import ContextManager
from whoosh.fields import Schema, TEXT, ID
from whoosh import index

import whoosh

from whoosh.qparser import QueryParser

import json

import csv
 
import os.path

from whoosh.qparser.syntax import WordNode
 
if not os.path.exists("indexdir"):
    os.mkdir("indexdir")
     
schema = Schema(content=TEXT(stored = True))
 
ix = index.create_in("indexdir", schema)

writer = ix.writer()

concept_words = []

# load all concept words
with open("Keywords-Springer.csv") as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=",")
    counter = 0
    for row in csv_reader:
        if counter == 100000:
            break
        concept_words.append(row[0])
        counter += 1
concept_words_frequency = {}
counter = 0
next_goal = 10000

# split all documents into sentences and write them into whoosh
with open('arxiv-metadata.json', "r") as files:
    for jsonObject in files:
        if counter == 1000000:
            break
        if counter == next_goal:
            print(next_goal)
            next_goal += 100
        abstract = (json.loads(jsonObject)["abstract"]).replace("\n", " ")
        sentences = abstract.split(".")
        for s in sentences:
            writer.add_document(content=s)
        for word in concept_words:
            if word in abstract:
                concept_words_frequency[word] = concept_words_frequency.get(word, 0) + 1
        counter += 1

writer.commit()
# concept_words_frequency store info of [word: word frequency in documents] and write the info into the file
with open("concept_words_frequency.txt", "w") as output:
    for k, v in concept_words_frequency.items():
        output.write(k)
        output.write(",")
        output.write(str(v))
        output.write("\n")
s_to_concept = {}
# search each concept word in the document sets and only keep the documents containing concepts
with open("concept_words_sentences", "w") as output:
    with ix.searcher() as searcher:
        for word in concept_words:
            # query = QueryParser("content", ix.schema).parse(word)
            arr = word.split(" ")
            w_to_search = []
            for element in arr:
                w_to_search.append(element)
            query = whoosh.query.Phrase("content", w_to_search)
            results = searcher.search(query, terms=True)
            for r in results:
                curr_sentence = r["content"]
                if curr_sentence not in s_to_concept:
                    s_to_concept[curr_sentence] = [word]
                else:
                    if word not in s_to_concept[curr_sentence]:
                        s_to_concept[curr_sentence].append(word)
    for key in s_to_concept.keys():
        output.write(key)
        for word in s_to_concept[key]:
            output.write(".")
            output.write(word)
        output.write("\n")


                


