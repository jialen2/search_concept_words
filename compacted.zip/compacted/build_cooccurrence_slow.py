import nltk
import csv
import json
from nltk.util import ngrams
import numpy as np
from numpy.core.numeric import _outer_dispatcher
concept_words = []

with open("Keywords-Springer.csv") as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=",")
    counter = 0
    for row in csv_reader:
        if counter == 10000:
            break
        concept_words.append(row[0])
        counter += 1
print("done loading keywords")
words = []
word_to_index = {}
def extract_ngrams(data, num):
    n_grams = ngrams(nltk.word_tokenize(data), num)
    for grams in n_grams:
        words.append(' '.join(grams))
word_index = 0
document_index = 0
total_document = 10000
counter = 0
df_table = np.array([[0]*total_document])
next_goal = 10
with open('arxiv-metadata.json', "r") as files:
    for jsonObject in files:
        if next_goal == counter:
            print(next_goal)
            next_goal += 10
        if counter == 10000:
            break
        abstract = json.loads(jsonObject)["abstract"]
        is_noun = lambda pos: pos[:2] == 'NN'
        tokenized = nltk.word_tokenize(abstract)
        words = [word for (word, pos) in nltk.pos_tag(tokenized) if is_noun(pos)]
        # for i in range(2, len(abstract) + 1):
        for i in range(2, 6):
            extract_ngrams(abstract, i)
        for word in words:
            if word not in word_to_index:
                word_to_index[word] = word_index
                word_index += 1
                if word_index != 1:
                    df_table = np.append(df_table, [[0]*total_document],axis=0)
            df_table[word_to_index[word]][document_index] += 1
        counter += 1
print("done loading all nouns")
concept_word_to_index = {}
for concept in concept_words:
    if concept in word_to_index:
        concept_word_to_index[concept] = word_to_index[concept]
concept_df = np.array([[0]*total_document])
for value in concept_word_to_index.values():
    concept_df = np.append(concept_df, [df_table[value]], axis=0)
np.delete(concept_df, [0])
print("done creating concept_df")
ct = np.dot(concept_df, np.transpose(concept_df))
print("done matrix multiplication")
with open("cooccurence_table_slow", "w") as output:
    for concept in concept_word_to_index:
        output.write(concept)
        output.write(",")
    output.write("\n")
    for row in ct:
        for item in row:
            output.write(item)
            output.write(",")
        output.write("\n")
