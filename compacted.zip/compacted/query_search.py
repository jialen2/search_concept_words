from multiprocessing import context
from typing import ContextManager, final
from whoosh.fields import Schema, TEXT, ID
from whoosh import index
# from whoosh.query import *

import whoosh
import math
import numpy as np
import time
 
import os.path
def findRelated(user_query):
    start_time = time.time()
    concept_to_index = {}
    concept_list = []
    with open('store_snippet', "r") as snippet_file, open("top_3_concepts", "r") as top_concepts:
        index = 0
        target_index = -1
        for row in top_concepts:
            if index == 0:
                strs = row.split(",")
                concept_index = 0
                # build up the concept_to_index and concept_list
                for concept in strs:
                    concept_to_index[concept] = concept_index
                    concept_list.append(concept)
                    concept_index += 1
                # if the user_query is in the concept word set, we use it as the target word.
                # if not, we will try to find its substring or superstring as the target word
                if user_query in concept_to_index:
                    target_index = concept_to_index[user_query] + 1
                else:
                    found = False
                    for concept in concept_to_index:
                        if user_query in concept or concept in user_query:
                            found = True
                            target_index = concept_to_index[concept]
                            break
                    if not found:
                        return -1
            elif index == target_index:
                indexs = row.split(",")
                count_index = 1
                for concept_index in range(3):
                    curr_concept = concept_list[int(indexs[concept_index])]
                    if int(indexs[concept_index]) == -1:
                        break
                    print(f"top {count_index} concept word is \"{curr_concept}\" with score of {indexs[concept_index + 3]}")
                    print("sample snippets are")
                    count_row = 0
                    snippet_file.seek(0)
                    for snippet_row in snippet_file:
                        if count_row == 9 * (target_index-1) + 3 * concept_index or count_row == 9 * (target_index-1) + 3 * concept_index + 1 or count_row == 9 * (target_index-1) + 3 * concept_index + 2:
                            snippet_row = snippet_row.replace("\n", "")
                            if snippet_row == "null":
                                break
                            print(snippet_row)
                            print("==============================")
                        if count_row == 9*target_index:
                            break
                        count_row += 1
                    count_index += 1
            index += 1
    print("search done. Time usage: ", str(time.time() - start_time))
                                  
              
def findUnRelated(user_query):
    start_time = time.time()
    if not os.path.exists("indexdir"):
        os.mkdir("indexdir")
        
    schema = Schema(content=TEXT(stored = True))
    
    concept_frequency_in_document = {}
    with open("concept_words_frequency.txt", "r") as f:
        for str in f:
            strs = str.split(",")
            concept_frequency_in_document[strs[0]] = int(strs[1])

    ix = index.create_in("indexdir", schema)

    # read sentences into whoosh writer
    writer = ix.writer()
    s_to_concepts = {}
    with open('concept_words_sentences', "r") as files:
        for str in files:
            str = str.replace("\n", "")
            concepts = str.split(".")
            writer.add_document(content=concepts[0])
            concept_list = []
            for con in concepts[1:]:
                concept_list.append(con)
                if concepts[0] not in s_to_concepts:
                    s_to_concepts[concepts[0]] = [con]
                else:
                    s_to_concepts[concepts[0]].append(con)
    writer.commit()

    from whoosh.qparser import QueryParser

    concept_frequency = {}
    
    with ix.searcher() as searcher:
        arr = user_query.split(" ")
        query_words = []
        for word in arr:
            query_words.append(word)
        query = whoosh.query.Phrase("content", query_words)
        # query = QueryParser("content", ix.schema).parse(f"'fuzzy artmap'~1 AND {user_query}~1")
        results = searcher.search(query, terms=True)
        for r in results[:1000]:
            for concept in s_to_concepts[r["content"]]:
                concept_frequency[concept] = concept_frequency.get(concept, 0) + 1
        for key in concept_frequency.keys():
            concept_frequency[key] *= math.log((1000000 + 1) / (concept_frequency_in_document.get(key,0) + 1))
        final_list = sorted(concept_frequency.items(), key=lambda x:x[1], reverse=True)
        found_concept = 0
        for i in range(len(final_list)):
            if found_concept == min(len(final_list), 3):
                break
            if final_list[i][0] == user_query:
                continue
            print(f"top {found_concept + 1} concept word is \"{final_list[i][0]}\" with score of {final_list[i][1]}")
            print("sample sentences are")
            arr = user_query.split(" ")
            query_words = []
            for word in arr:
                query_words.append(word)
            query_phrase = whoosh.query.Phrase("content", query_words)

            arr = final_list[i][0].split(" ")
            concept_words = []
            for word in arr:
                concept_words.append(word)
            concept_phrase = whoosh.query.Phrase("content", concept_words)
            query = QueryParser("content", ix.schema).parse(f"{concept_phrase} AND {query_phrase}")
            # query = whoosh.query.Phrase("content", query_words)
            results = searcher.search(query, terms=True)
            for r in results[:3]:
                print(r["content"])
            print("==============================")
            found_concept += 1
    time_spent = (time.time() - start_time)
    print("search done. Time usage: ", time_spent, "s")


def main():
    query = input("Please enter your query: ")
    relatedOrNot = ""
    while relatedOrNot not in ["Y", 'y', 'N', 'n']:
        relatedOrNot = input("Is the query related to the concept words set? [Y/N]: ")
    if relatedOrNot in ["Y", "y"]:
        if findRelated(query) == -1:
            print("Sorry, your query is not quite related. Please try again")
    else:
        findUnRelated(query)
    
main()
    
        

        
                