from multiprocessing import context
from multiprocessing.process import current_process
from os import write
from typing import ContextManager
from whoosh.fields import NUMERIC, Schema, TEXT, ID
from whoosh import index

import numpy as np

import whoosh

from whoosh.qparser import QueryParser

import json

import csv
 
import os.path

from whoosh.qparser.syntax import WordNode
concept_words = []

with open("Keywords-Springer.csv") as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=",")
    counter = 0
    for row in csv_reader:
        if counter == 10000:
            break
        concept_words.append(row[0])
        counter += 1
print("done with keyword")
words = []
word_to_index = {}
schema = Schema(content=TEXT(stored = True), index=NUMERIC(stored=True))
 
ix = index.create_in("indexdir", schema)

writer = ix.writer()

word_index = 0
document_index = 0
total_document = 10000
counter = 0
# df_table = np.array([[0]*total_document]*len(concept_words))
with open('arxiv-metadata.json', "r") as files:
    for jsonObject in files:
        if counter == 10000:
            break
        abstract = (json.loads(jsonObject)["abstract"]).replace("\n", " ")
        writer.add_document(content=abstract, index=document_index)
        document_index += 1
        counter += 1

writer.commit()
print("read document done")

ct = np.array([[0]*len(concept_words)]*len(concept_words))
count_i = 100
# with open("store_snippet", "w") as output:
with ix.searcher() as searcher:
    for i in range(len(concept_words)):
        if count_i == i:
            print(count_i)
            count_i += 100
        for j in range(i + 1, len(concept_words)):
            query = QueryParser("content", ix.schema).parse(f"{concept_words[i]}~1", f"{concept_words[j]}~1")
            results = searcher.search(query, terms=True)
            snippet_count = 0
            for r in results:
                document = r["content"]
                first_index = document.find(concept_words[i])
                second_index = document.find(concept_words[j])
                distance = abs(first_index - second_index)
                # if distance < 55:
                    # output.write(document[max(0,min(first_index, second_index)-25):min(max(first_index, second_index)+30,len(document))])
                    # output.write("\n")
                # else:
                    # output.write(document[max(0,min(first_index, second_index)-25):min(min(first_index, second_index)+30,len(document))])
                    # output.write("...")
                    # output.write(document[max(0,max(first_index, second_index)-25):min(max(first_index, second_index)+30,len(document))])
                    # output.write("\n")
                ct[i][j] += (100 / (distance+1))
            #     snippet_count += 1
            # while snippet_count < 3:
                # output.write("null")
                # output.write("\n")
                # snippet_count += 1
    # for concept in concept_words:
    #     query = QueryParser("content", ix.schema).parse(f"{concept}~1")
    #     results = searcher.search(query, terms=True)
    #     for r in results:
    #         df_table[word_index][r["index"]] += 1
    #     word_index += 1
print("search done")

# ct = np.dot(df_table, np.transpose(df_table))
# print("matrix multiply done")

with open("cooccurance_table", "w") as output:
    for concept in concept_words:
        output.write(concept)
        output.write(",")
    output.write("\n")
    for row in ct:
        for item in row:
            output.write(item)
            output.write(",")
        output.write("\n")


        
        

