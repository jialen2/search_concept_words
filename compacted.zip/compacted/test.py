from multiprocessing import context
from multiprocessing.process import current_process
from os import write
import re
from typing import ContextManager
from numpy.lib.shape_base import take_along_axis
from whoosh.fields import NUMERIC, Schema, TEXT, ID
from whoosh import index

import numpy as np

import whoosh

from whoosh.qparser import QueryParser

import json

import csv
 
import os.path

from whoosh.qparser.syntax import WordNode

import time

start_time = time.time()
time_spent = str(time.time() - start_time)
print("search done. Time usage: ", time_spent, "s")

# schema = Schema(content=TEXT(stored = True), index=NUMERIC(stored=True))

# ix = index.create_in("indexdir", schema)

# writer = ix.writer()

# writer.add_document(content="help use machine learning first sample task", index=0)

# writer.add_document(content="machine learning is too strong sample task", index=2)

# writer.add_document(content="build machine different learning first task", index=1)

# writer.add_document(content="to use machine learning", index=3)

# writer.commit()

# concept = "machine learning"
# ano = "sample task"

# with ix.searcher() as searcher:
#     arr = concept.split(" ")
#     query_words = []
#     for word in arr:
#         query_words.append(word)
#     concept_query = whoosh.query.Phrase("content", query_words)

#     arr = ano.split(" ")
#     ano_words = []
#     for word in arr:
#         ano_words.append(word)
#     ano_query = whoosh.query.Phrase("content", ano_words)  
#     query = QueryParser("content", ix.schema).parse(f"{concept_query} AND {ano_query}")
#     # query = whoosh.query.Phrase("content", query_words)
#     results = searcher.search(query, terms=True)
#     for r in results:
#         print(r["content"])
#         print(r["index"])



